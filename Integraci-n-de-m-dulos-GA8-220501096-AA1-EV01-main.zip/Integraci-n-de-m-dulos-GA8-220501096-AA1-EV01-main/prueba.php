<?php
echo "PRUEBA OK: " . __FILE__;
